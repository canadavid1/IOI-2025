#include <vector>

int send_message(int N, int i, int Pi);

std::pair<int, int> longest_path(std::vector<int> S);
