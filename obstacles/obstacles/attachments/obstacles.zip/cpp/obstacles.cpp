#include "obstacles.h"

void initialize(std::vector<int> T, std::vector<int> H) {
  return;
}

bool can_reach(int L, int R, int S, int D) {
  return false;
}
