#include <vector>

void initialize(std::vector<int> T, std::vector<int> H);

bool can_reach(int L, int R, int S, int D);
