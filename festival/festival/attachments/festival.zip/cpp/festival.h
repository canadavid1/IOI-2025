#include <vector>

std::vector<int> max_coupons(int A, std::vector<int> P, std::vector<int> T);
